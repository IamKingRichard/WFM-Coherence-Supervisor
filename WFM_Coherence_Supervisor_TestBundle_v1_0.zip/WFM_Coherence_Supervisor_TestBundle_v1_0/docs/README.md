# WFM Coherence Supervisor – Test Bundle v1.0

Author: King Richard Charles Talley  
Date: November 8, 2025  

## Purpose

Supervisory AUTOSAR SWC for EV drivetrain efficiency and coherence optimization.  
Advisory-only: bounded bias factors to existing torque/regen/PWM controllers.  
No direct actuator authority.

## Contents

- `src/Wfm_Supervisor_Run.c` – Runnable implementation.
- `include/WfmCoherenceSupervisor.arxml` – Minimal SWC declaration.
- `config/WFM_DefaultCalibrations.txt` – Initial calibration set.
- `docs/README.md` – This file.

## Integration (Quick)

1. Import `include/WfmCoherenceSupervisor.arxml` into your AUTOSAR tool.
2. Connect:
   - `R_Telemetry` to inverter/BMS telemetry.
   - `P_Biases` to Torque/Regen controllers (S-R inputs).
   - `P_Diagnostics` to diag/telemetry (optional).
3. Generate `Rte_WfmCoherenceSupervisor.h`.
4. Add `src/Wfm_Supervisor_Run.c` to the ECU build.
5. Apply defaults from `config/WFM_DefaultCalibrations.txt`.

## Behavior

- Enabled & valid:
  - Computes coherence (Xi) and spread (S_norm).
  - Outputs:
    - `torque_smoothing_factor` in [0.7, 1.0]
    - `regen_gain` in [0.85, 1.15]
    - `pwm_opt_mode` in {0, 1}
    - `aux_phase_scheduling` in [0.0, 1.0]
- Disabled or invalid:
  - Neutral:
    - `1.0, 1.0, 0, 0.0`

Ready for dyno / HIL A/B testing vs baseline.
