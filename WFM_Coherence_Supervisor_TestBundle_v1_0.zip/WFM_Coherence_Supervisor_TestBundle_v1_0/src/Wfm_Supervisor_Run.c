
#include "Rte_WfmCoherenceSupervisor.h"

#define WFM_STATUS_OK        ((uint8)0u)
#define WFM_STATUS_DEGRADED  ((uint8)1u)
#define WFM_STATUS_OFF       ((uint8)2u)

#define WFM_TORQUE_SMOOTHING_NEUTRAL   (1.0f)
#define WFM_REGEN_GAIN_NEUTRAL         (1.0f)
#define WFM_PWM_OPT_MODE_NEUTRAL       ((uint8)0u)
#define WFM_AUX_PHASE_SCHED_NEUTRAL    (0.0f)

#define WFM_MAX_WINDOW_SIZE  (64u)

typedef struct
{
    float32 tCmdHist[WFM_MAX_WINDOW_SIZE];
    float32 tActHist[WFM_MAX_WINDOW_SIZE];
    uint16  index;
    uint16  count;
    boolean initialized;
} WfmHistoryType;

static WfmHistoryType WfmHistory = {
    {0}, {0}, 0u, 0u, FALSE
};

static float32 Wfm_Clamp_f32(float32 x, float32 minVal, float32 maxVal)
{
    if (x < minVal) return minVal;
    if (x > maxVal) return maxVal;
    return x;
}

static float32 Wfm_MapLinear(float32 x,
                             float32 xMin, float32 xMax,
                             float32 yMin, float32 yMax)
{
    if (x <= xMin) return yMin;
    if (x >= xMax) return yMax;
    {
        float32 t = (x - xMin) / (xMax - xMin);
        return yMin + t * (yMax - yMin);
    }
}

void Wfm_Supervisor_Run(void)
{
    boolean WFM_ENABLE      = Rte_Prm_WFM_ENABLE();
    float32 Xi_min          = Rte_Prm_Xi_min();
    float32 Xi_high         = Rte_Prm_Xi_high();
    float32 alpha_S         = Rte_Prm_alpha_S();
    float32 alpha_Xi        = Rte_Prm_alpha_Xi();
    float32 eta_phys_max    = Rte_Prm_eta_phys_max();
    uint16  window_size     = Rte_Prm_window_size();
    uint8   num_bins        = Rte_Prm_num_bins();

    (void)alpha_S;
    (void)alpha_Xi;
    (void)num_bins;

    if ((window_size == 0u) || (window_size > WFM_MAX_WINDOW_SIZE))
    {
        window_size = WFM_MAX_WINDOW_SIZE;
    }

    float32 T_cmd = 0.0f;
    float32 T_act = 0.0f;
    float32 I_dc = 0.0f;
    float32 V_dc = 0.0f;
    float32 T_batt = 0.0f;
    float32 T_inverter = 0.0f;
    float32 vehicle_speed = 0.0f;
    float32 delta_cmd = 0.0f;
    boolean temps_ok = FALSE;
    uint8   valid_flags = 0u;

    (void)Rte_Read_R_Telemetry_T_cmd(&T_cmd);
    (void)Rte_Read_R_Telemetry_T_act(&T_act);
    (void)Rte_Read_R_Telemetry_I_dc(&I_dc);
    (void)Rte_Read_R_Telemetry_V_dc(&V_dc);
    (void)Rte_Read_R_Telemetry_T_batt(&T_batt);
    (void)Rte_Read_R_Telemetry_T_inverter(&T_inverter);
    (void)Rte_Read_R_Telemetry_vehicle_speed(&vehicle_speed);
    (void)Rte_Read_R_Telemetry_delta_cmd(&delta_cmd);
    (void)Rte_Read_R_Telemetry_temps_ok(&temps_ok);
    (void)Rte_Read_R_Telemetry_valid_flags(&valid_flags);

    float32 torque_smoothing_factor = WFM_TORQUE_SMOOTHING_NEUTRAL;
    float32 regen_gain              = WFM_REGEN_GAIN_NEUTRAL;
    uint8   pwm_opt_mode            = WFM_PWM_OPT_MODE_NEUTRAL;
    float32 aux_phase_scheduling    = WFM_AUX_PHASE_SCHED_NEUTRAL;
    uint8   wfm_status              = WFM_STATUS_OFF;
    float32 Xi                      = 1.0f;
    float32 S_norm                  = 0.0f;

    (void)valid_flags;
    {
        boolean basic_valid = (temps_ok == TRUE) && (V_dc > 10.0f);

        if ((WFM_ENABLE == FALSE) || (basic_valid == FALSE))
        {
            if (WFM_ENABLE == FALSE)
            {
                wfm_status = WFM_STATUS_OFF;
            }
            else
            {
                wfm_status = WFM_STATUS_DEGRADED;
            }

            (void)Rte_Write_P_Biases_torque_smoothing_factor(torque_smoothing_factor);
            (void)Rte_Write_P_Biases_regen_gain(regen_gain);
            (void)Rte_Write_P_Biases_pwm_opt_mode(pwm_opt_mode);
            (void)Rte_Write_P_Biases_aux_phase_scheduling(aux_phase_scheduling);

            (void)Rte_Write_P_Diagnostics_Xi(Xi);
            (void)Rte_Write_P_Diagnostics_S_norm(S_norm);
            (void)Rte_Write_P_Diagnostics_wfm_status(wfm_status);
            return;
        }
    }

    wfm_status = WFM_STATUS_OK;

    if (WfmHistory.initialized == FALSE)
    {
        uint16 i;
        for (i = 0u; i < window_size; i++)
        {
            WfmHistory.tCmdHist[i] = T_cmd;
            WfmHistory.tActHist[i] = T_act;
        }
        WfmHistory.index = 0u;
        WfmHistory.count = window_size;
        WfmHistory.initialized = TRUE;
    }
    else
    {
        WfmHistory.tCmdHist[WfmHistory.index] = T_cmd;
        WfmHistory.tActHist[WfmHistory.index] = T_act;

        WfmHistory.index++;
        if (WfmHistory.index >= window_size)
        {
            WfmHistory.index = 0u;
        }

        if (WfmHistory.count < window_size)
        {
            WfmHistory.count++;
        }
    }

    {
        uint16 n = WfmHistory.count;
        if (n > 1u)
        {
            float32 sumCmd = 0.0f, sumAct = 0.0f;
            float32 sumCmd2 = 0.0f, sumAct2 = 0.0f, sumProd = 0.0f;
            uint16 i;

            for (i = 0u; i < n; i++)
            {
                float32 c = WfmHistory.tCmdHist[i];
                float32 a = WfmHistory.tActHist[i];
                sumCmd  += c;
                sumAct  += a;
                sumCmd2 += c * c;
                sumAct2 += a * a;
                sumProd += c * a;
            }

            float32 invN = 1.0f / (float32)n;
            float32 meanCmd = sumCmd * invN;
            float32 meanAct = sumAct * invN;

            float32 varCmd = (sumCmd2 * invN) - (meanCmd * meanCmd);
            float32 varAct = (sumAct2 * invN) - (meanAct * meanAct);
            float32 cov    = (sumProd * invN) - (meanCmd * meanAct);

            if ((varCmd > 1e-6f) && (varAct > 1e-6f))
            {
                float64 denom = (float64)varCmd * (float64)varAct;
                if (denom > 0.0)
                {
                    float32 corr = cov / (float32)sqrt(denom);
                    if (corr < 0.0f) { corr = -corr; }
                    Xi = Wfm_Clamp_f32(corr, 0.0f, 1.0f);
                }
            }
            else
            {
                Xi = 1.0f;
            }

            if (varCmd > 0.0f)
            {
                float32 spread = (float32)sqrt((float64)varCmd);
                float32 denomS = (float32)fabs((float64)meanCmd) + 1.0f;
                S_norm = Wfm_Clamp_f32(spread / denomS, 0.0f, 1.0f);
            }
            else
            {
                S_norm = 0.0f;
            }
        }
        else
        {
            Xi = 1.0f;
            S_norm = 0.0f;
        }
    }

    torque_smoothing_factor =
        Wfm_MapLinear(Xi, Xi_min, Xi_high,
                      0.7f, 1.0f);
    torque_smoothing_factor =
        Wfm_Clamp_f32(torque_smoothing_factor, 0.7f, 1.0f);

    {
        float32 xiGain = Wfm_MapLinear(Xi, Xi_min, Xi_high,
                                       0.95f, 1.10f);
        regen_gain = Wfm_Clamp_f32(xiGain, 0.85f, 1.15f);
    }

    if ((Xi >= Xi_high) && (I_dc > 0.0f) && (I_dc < (0.7f * eta_phys_max)))
    {
        pwm_opt_mode = 1u;
    }
    else
    {
        pwm_opt_mode = 0u;
    }

    aux_phase_scheduling = 1.0f - S_norm;
    aux_phase_scheduling =
        Wfm_Clamp_f32(aux_phase_scheduling, 0.0f, 1.0f);

    (void)Rte_Write_P_Biases_torque_smoothing_factor(torque_smoothing_factor);
    (void)Rte_Write_P_Biases_regen_gain(regen_gain);
    (void)Rte_Write_P_Biases_pwm_opt_mode(pwm_opt_mode);
    (void)Rte_Write_P_Biases_aux_phase_scheduling(aux_phase_scheduling);

    (void)Rte_Write_P_Diagnostics_Xi(Xi);
    (void)Rte_Write_P_Diagnostics_S_norm(S_norm);
    (void)Rte_Write_P_Diagnostics_wfm_status(wfm_status);
}
